"""
Basic NLP Sentiment Analysis Pipeline for E-commerce Product Reviews
--------------------------------------------------------------------
Steps:
 1. Raw input review
 2. Lowercasing
 3. Noise removal (HTML tags, URLs, numbers, extra spaces)
 4. Punctuation removal
 5. Stop-word removal
 6. Lemmatization
 7. Tokenization
 8. Unique words (vocabulary)
 9. Feature extraction (Bag of Words / TF-IDF)
Then: model training -> prediction on user input.

Install:  pip install nltk scikit-learn
"""

import re
import string

import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split

# ---------------------------------------------------------------
# One-time download of NLTK resources
# ---------------------------------------------------------------
for pkg in ["punkt", "punkt_tab", "stopwords", "wordnet", "omw-1.4"]:
    nltk.download(pkg, quiet=True)

# ---------------------------------------------------------------
# Sample dataset (replace with your real e-commerce reviews / CSV)
# label: 1 = positive, 0 = negative
# ---------------------------------------------------------------
DATA = [
    ("Absolutely love this phone! Battery lasts all day.", 1),
    ("Great quality and fast delivery. Highly recommended!", 1),
    ("The product is amazing, works perfectly.", 1),
    ("Very comfortable shoes, perfect fit and good looking.", 1),
    ("Excellent value for money. I am very happy with it.", 1),
    ("Superb sound quality, best headphones I have bought.", 1),
    ("Easy to use and looks beautiful. Five stars!", 1),
    ("Fantastic laptop, super fast and light weight.", 1),
    ("Good packaging and the item works as described.", 1),
    ("I really like this t-shirt, soft and stylish.", 1),
    ("Worst product ever. Stopped working after two days.", 0),
    ("Terrible quality, waste of money.", 0),
    ("Very disappointed, the item arrived broken.", 0),
    ("Poor battery life and the screen is bad.", 0),
    ("Not worth the price. Cheap material and bad stitching.", 0),
    ("Delivery was late and the product was damaged.", 0),
    ("Awful experience, customer support did not help.", 0),
    ("The shoes are uncomfortable and fell apart quickly.", 0),
    ("I hate it. Does not work and I want a refund.", 0),
    ("Bad sound, very noisy and not as described.", 0),
]

# Keep negation words: they matter a lot in sentiment ("not good")
STOP_WORDS = set(stopwords.words("english")) - {"not", "no", "nor", "never"}
LEMMATIZER = WordNetLemmatizer()


# ---------------------------------------------------------------
# Preprocessing steps (each step is its own function)
# ---------------------------------------------------------------
def to_lower(text):                       # Step 2
    return text.lower()


def remove_noise(text):                   # Step 3
    text = re.sub(r"<.*?>", " ", text)            # HTML tags
    text = re.sub(r"http\S+|www\.\S+", " ", text)  # URLs
    text = re.sub(r"\d+", " ", text)               # numbers
    text = re.sub(r"\s+", " ", text).strip()       # extra spaces
    return text


def remove_punctuation(text):             # Step 4
    return text.translate(str.maketrans("", "", string.punctuation))


def remove_stopwords(text):               # Step 5
    return " ".join(w for w in text.split() if w not in STOP_WORDS)


def lemmatize(text):                      # Step 6
    return " ".join(LEMMATIZER.lemmatize(w) for w in text.split())


def tokenize(text):                       # Step 7
    return word_tokenize(text)


def preprocess(raw_review, verbose=False):
    """Run steps 1-7 on a single review and return the list of tokens."""
    steps = [
        ("1. Raw review", None),
        ("2. Lowercase", to_lower),
        ("3. Noise removed", remove_noise),
        ("4. Punctuation removed", remove_punctuation),
        ("5. Stop words removed", remove_stopwords),
        ("6. Lemmatized", lemmatize),
    ]
    text = raw_review
    for name, func in steps:
        if func is not None:
            text = func(text)
        if verbose:
            print(f"{name:<25}: {text}")

    tokens = tokenize(text)
    if verbose:
        print(f"{'7. Tokens':<25}: {tokens}")
    return tokens


# ---------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------
def main():
    reviews = [r for r, _ in DATA]
    labels = [y for _, y in DATA]

    # Show the preprocessing steps on one example review
    print("=" * 60)
    print("PREPROCESSING DEMO (first review)")
    print("=" * 60)
    preprocess(reviews[0], verbose=True)

    # Steps 1-7 for every review
    all_tokens = [preprocess(r) for r in reviews]
    clean_text = [" ".join(t) for t in all_tokens]

    # Step 8: unique words (vocabulary)
    unique_words = sorted({w for tokens in all_tokens for w in tokens})
    print("\n" + "=" * 60)
    print(f"UNIQUE WORDS ({len(unique_words)})")
    print("=" * 60)
    print(unique_words)

    # Step 9: feature extraction (TF-IDF)
    # Alternative: from sklearn.feature_extraction.text import CountVectorizer
    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(clean_text)
    print("\n" + "=" * 60)
    print("FEATURE EXTRACTION (TF-IDF)")
    print("=" * 60)
    print("Feature matrix shape (reviews x words):", X.shape)

    # Model training
    X_train, X_test, y_train, y_test = train_test_split(
        X, labels, test_size=0.25, random_state=42, stratify=labels
    )
    model = LogisticRegression()
    model.fit(X_train, y_train)

    # Evaluation
    y_pred = model.predict(X_test)
    print("\n" + "=" * 60)
    print("MODEL EVALUATION")
    print("=" * 60)
    print("Accuracy:", accuracy_score(y_test, y_pred))
    print(classification_report(y_test, y_pred, zero_division=0,
                                target_names=["Negative", "Positive"]))

    # Prediction on user input
    print("=" * 60)
    print("PREDICT YOUR OWN REVIEW  (type 'quit' to exit)")
    print("=" * 60)
    while True:
        user_review = input("\nEnter a product review: ").strip()
        if user_review.lower() in {"quit", "exit", "q"}:
            break
        if not user_review:
            continue

        print()
        tokens = preprocess(user_review, verbose=True)
        features = vectorizer.transform([" ".join(tokens)])
        pred = model.predict(features)[0]
        prob = model.predict_proba(features)[0][pred]
        label = "POSITIVE 😊" if pred == 1 else "NEGATIVE 😞"
        print(f"\nPrediction: {label}  (confidence: {prob:.2f})")


if __name__ == "__main__":
    main()
